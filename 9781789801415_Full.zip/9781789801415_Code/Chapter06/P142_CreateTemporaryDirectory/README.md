# Working with temporary files/folders
Write several programs for working with temporary files/folders.
