# Reading/writing binary files efficiently
Write several programs for exemplifying different approaches for reading and writing a binary file in an efficient manner.
