# Converting file paths
Write several examples for converting file paths (e.g., convert file path to string, URI, file, etc).
