# Creating file paths
Write several examples for creating different kind of file paths (e.g., absolute paths, relative paths, etc).
