# LVTI and the ternary operator
Write several snippets of code that exemplifies the advantages of combining LVTI and the ternary operator.
