# LVTI, wildcards, covariants and contravariants
Write several snippets of code that exemplifies how LVTI can be used in combination with wildcards, covariants and contravariants.
