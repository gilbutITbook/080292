# Checking index in the range from 0 to length
Write a program that checks if the given index is between 0 (inclusive) and the given length (exclusive). If the given index is out of the [0, given length) range then throw an **IndexOutOfBoundsException**.
