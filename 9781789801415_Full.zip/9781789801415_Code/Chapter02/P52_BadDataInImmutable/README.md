# Bad data in immutable objects
Write a program that prevents bad data in immutable objects.