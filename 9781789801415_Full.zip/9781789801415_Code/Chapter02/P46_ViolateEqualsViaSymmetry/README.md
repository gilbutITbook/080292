# Violate equals() Symmetry Via Inheritance
Write a program that violates **equals()** symmetry via inheritance and fix the problem via composition.
