# Checking null references and return non-null default references
Write a program that performs **null** checks on the given reference and if it is non-**null** then return it, otherwise return a non-**null** default reference.
