# Checking null references and throw the specified exception (e.g. IllegalArgumentException)
Write a program that performs **null** checks on the given references and throw the specified exception.
