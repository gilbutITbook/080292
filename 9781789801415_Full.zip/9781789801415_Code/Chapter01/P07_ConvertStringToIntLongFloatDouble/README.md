# Convert String to int, long, float and double
Write a program that converts the given string (representing a number) to an **int**, **long**, **float** and **double**.