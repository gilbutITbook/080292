# Apply logical And/Or/Xor to two booleans
Write a program that applies the logical **And**/**Or**/**Xor** to two boolean expressions.