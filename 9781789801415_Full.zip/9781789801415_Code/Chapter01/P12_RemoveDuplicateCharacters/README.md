# Remove duplicate characters
Write a program that removes the duplicate characters from the given string.