# Remove given characters
Write a program that removes the given character from the given string.