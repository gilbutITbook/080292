# Compute the floor of a division and modulus
Write a program that computes the floor division and the floor modulus of the given dividend (**x**) and divisor (**y**).