# Sort array of strings by the length
Write a program that sorts by length the given array of strings.