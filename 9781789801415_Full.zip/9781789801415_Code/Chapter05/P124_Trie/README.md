# Trie
Write a program that implements a Trie data structure.
