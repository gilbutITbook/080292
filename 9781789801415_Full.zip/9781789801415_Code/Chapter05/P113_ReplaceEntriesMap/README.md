# Replacing entries from a Map
Write a program that replaces the given entries from a **Map**.
