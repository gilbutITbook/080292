# Increasing array size
Write a program that adds an element into an array by increasing its size by 1. In addition, write a program that increase the size of an array with the given length.
